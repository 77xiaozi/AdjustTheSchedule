//
//  AppDelegate.h
//  JKCircleViewDemo
//
//  Created by kunge on 16/9/2.
//  Copyright © 2016年 kunge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

